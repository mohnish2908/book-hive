package com.library.project.college.PrivateLibrary.exceptions;

public class ResourceNotFoundException extends RuntimeException{

     public ResourceNotFoundException(String message){
        super(message);
    }
}
