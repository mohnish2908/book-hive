package com.library.project.college.PrivateLibrary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrivateLibraryApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrivateLibraryApplication.class, args);
		System.out.println("App is Running");
	}
}
