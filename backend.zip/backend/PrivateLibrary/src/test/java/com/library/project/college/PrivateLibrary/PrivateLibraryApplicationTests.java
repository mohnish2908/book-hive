package com.library.project.college.PrivateLibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrivateLibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
